class Button{
  constructor(xPos, yPos, lbl, type){
    this.x=xPos-250;
    this.y=yPos+275;
    this.label=lbl;
    this.button= createButton(this.label);
    this.w=this.button.size().width;
    this.h=this.button.size().height;
    this.clicked=false;
  }
  
  display(){
  this.button.position(this.x, this.y);
  }
  
  click(mx, my){
   if(mx> this.x && mx<this.x+this.w && my>this.y && my<=this.y+this.h && mouseIsPressed){
     this.clicked=true;
     return true;
   }
    else{
      this.clicked=false;
      return false;
    }
  }
  
  getLabel(){
    return this.label;
  }
  
  getWidth(){
   return this.w;
  }
  
}