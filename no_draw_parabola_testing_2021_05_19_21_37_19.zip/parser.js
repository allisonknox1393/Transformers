//types:
//0 means circle
//1 means parabola
//2 means 

class Parser{

  constructor(submission, type){
    this.submit=submission;
    this.eq= type;
   
  }
  
  determineMethod(){
    if(this.eq.localeCompare()){
      
    }
  }
  
  
}