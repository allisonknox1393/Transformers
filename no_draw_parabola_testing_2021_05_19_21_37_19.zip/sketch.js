var axisFont; //global font var
var startScreenFont; //global font var 
var startGame; //global button to start game

var showRadius;
var startScreen; //boolean when true start screen displayed
var tutorial1;
var level1; //boolean when true lvl1 displayed
var level2;
var level3;
var img; 
var imgWidth=1220;
var eq1;
var submit1;
var eq2;
var submit2;
var parseLevelTwo;

//loads font assets
function preload(){
   axisFont = loadFont('assets/CrimsonText-Regular.ttf');
  startScreenFont = loadFont('assets/ShortStack-Regular.ttf');
  img= loadImage('assets/background.jpg');
}

function setup(){
  createCanvas(1200, 1000);
  background(img);
  ellipseMode(RADIUS);
  rectMode(CENTER);
  this.showRadius=false;
  startScreen = true; //should be true but testing stuff out
  tutorial1=false;
  level1 = false; //should be false
  level2= false;
  level3=false;
  img.resize(imgWidth, windowHeight);
  //implementing parser stuff
  parseLevelTwo=false;
    noLoop();
}

function draw(){
  background(255);
  image(img, 0, 0);
  image(img, 0, img.height);
  if(startScreen){
    drawStartScreen();
  }
  else if(tutorial1){
    drawTutorialOne();
  }
  else if(level1){
    drawLevelOne();
  }
  else if(level2){
    drawLevelTwo();
  }
}

function keyPressed(){
  if(key==' '){
    redraw();
  }
}

function drawStartScreen(){
  textFont(startScreenFont);
  textSize(25);
  text('WELCOME,', windowWidth/4+200, windowHeight/2-60);
  textSize(75);
  text('TRANSFORMERS', windowWidth/4, windowHeight / 2);
  textSize(25);
  text('YOU READY TO GET DOWN TO BUSINESS?', windowWidth/4+100, windowHeight/2+50);
  startGame = createButton('ENTER GAME MODE');
  startGame.id('start-game');
  startGame.position(windowWidth / 2 + 100, windowHeight / 2 + 100);
  startGame.mousePressed(flipLevelOne);
    
  let tutorial= createButton('SHOW ME HOW TO PLAY');
  tutorial.id('start-game');
  tutorial.position(windowWidth/2-100, windowHeight/2+100);
  tutorial.mousePressed(flipTutorial);
}


function flipTutorial(){
  startScreen=false;
  tutorial1=true;
  removeElements(); 
  redraw();
}

function drawTutorialOne(){
  let centerW=windowWidth/2;
  let centerH=windowHeight/2;
  drawGrid(centerW, centerH);
  text('TUTORIAL', windowWidth/2, windowHeight/2+300);
  let startLevel1=createButton('START LEVEL ONE');
  startLevel1.id('start-game');
  startLevel1.position(windowWidth/2, windowHeight/2+400);
  startLevel1.mousePressed(flipLevelOne);
}


function flipLevelOne(){
  startScreen=false;
  tutorial1=false;
  level1=true;
  removeElements();
  redraw();
}

function drawLevelOne(){
  centerW=windowWidth/2;
  centerH=windowHeight/2;
  drawGrid(centerW, centerH);
  firstLevel(centerW, centerH);
}

function firstLevel(originX, originY){
  strokeWeight(2);
  noFill();
  drawCircle(0, 0, 9, originX, originY, false);
  drawParabola(1/2, -3,-2, -5, -1, originX, originY);
  this.eq1= createInput();
  this.submit1=createButton('submit circle');
  this.eq1.position(originX, 700); this.submit1.position(this.eq1.x+this.eq1.width, 700);
    this.submit1.mousePressed(parseCircleInput);

  this.eq2=createInput();
  this.submit2=createButton('submit parabola');
  this.eq2.position(originX, 800);  this.submit2.position(this.eq2.x+this.eq2.width, 800);
  this.submit2.mousePressed(parseParabolaInput);
  levelButtons();
}

function levelButtons(){
    let toggle=createButton('TOGGLE CENTER AND RADIUS DISPLAY');
  toggle.position(10, 200);
  toggle.mousePressed(toggleRadius);
  let clearTrials=createButton('CLEAR GRID');
  clearTrials.position(10, 220);
  clearTrials.mousePressed(clearGrid);
}

function clearGrid(){
  redraw();
}

function toggleRadius(){
  showRadius=!showRadius;
  redraw();
}

function parseCircleInput(){
  let centerW=windowWidth/2;
  let centerH=windowHeight/2;
  let equation=eq1.value();
  let circle='\\(x(\\+\\d|\\-\\d)\\)\\^2\\+\\(y(\\+\\d|\\-\\d)\\)\\^2\\=(\\-\\d|\\d)';
  let returned= match(equation, circle);
  let h=parseInt(returned[1]);
  let k=parseInt(returned[2]);
  let r=parseInt(returned[3]);
  print(h+ " " + k + " " + r);
  drawCircle(h, k, r, centerW, centerH, true);
}

function parseParabolaInput(){
  let centerW=windowWidth/2;
  let centerH=windowHeight/2;
  let equation=eq2.value();
  let parabola='y\\=(\\d|\\-\\d|\\d\\/\\d|\\-\\d\\/\\d)\\(x(\\+\\d|\\-\\d)\\)\\^2(\\+\\d|\\-\\d)';
  
  let returned=match(equation, parabola);
  print(returned);
  let a=returned[1];
  
  //if a is a fraction
  if(returned[1].includes('/')){
    let newFraction= split(returned[1], '/');
    let f1=newFraction[0];
    let f2=newFraction[1];
    a=parseFloat(f1/f2);
  }
  
  let h=returned[2];
  let k=returned[3];
  drawParabola(a, h, k, 0, 6, centerW, centerH, true);
  //IMPLEMENT BOUNDS LOWER AND UPPER
}

function drawParabola(a, h, k, lower, upper, originX, originY, user){
  originY=originY-100;//dont forget this!
   let unit=25;
  let x1=null;//x intercept
  let x2=null; //x intercept
  if(user){
    stroke(0,0,255);
  }
  else{
    stroke(255,0,0);
  }
  push();
  noFill();
    translate((-1*h)*unit+originX, (-1*k)*unit+originY);
  print("x: "+ ((-1*h)*unit+originX) +" y: " + ((-1*k)*unit+originY));

  if(a>0){
    rotate(PI);
    print("a is positive");
  }
  else if(a<0){
    rotate(-PI);
    print("a is negative");
  }

  beginShape();
  let upperBound=0;
  for(let i=-h; i<upper; i++){
    upperBound+=1;
  }
  // for(let i=upper; i>h; i--){
  //   upperBound+=1;
  // }
 // let upperBound=abs(abs(upper)-abs(h));
  print("upper bound is " + upperBound);
  for(let i=0; i<=upperBound; i+=0.01){
    let x=-i*unit;
    let y=(i*i)*unit*a;
    vertex(x, y);
    if(y==-unit*k){ //for toggle radius
      x1=x;
    }
    //print("i is " + i + "(" +x +", " + y+ ")");
  }

  endShape();
  beginShape();
  let lowerBound=0;
  for(let i=-h; i>lower; i--){
    lowerBound+=1;
  }
  //let lowerBound=abs(abs(h)-abs(lower));
  for(let i=0; i<=lowerBound; i+=0.01){
    let x=i*unit;
    let y=(i*i)*unit*a;
    if(y==-unit*k){
      x2=x;
      print("x2 is " + x + " and y is " +y);
    }
    vertex(x, y);
  }
  print("lower bound is " + lowerBound);
  
  endShape();
  pop();
  
  //toggle radius stuff
  push();
  translate((-1*h)*unit+originX, originY);

  if(this.showRadius){
    if(user){
      fill(0,0,255);
    }
    else{
      fill(0);
      stroke(0);
    }
    circle(0, -unit*k, 3, 3);
    if(x1!=null && x2!=null){
      circle(x1, 0, 3, 3);
      circle(x2, 0, 3, 3);
    }
  }
  pop();
}



function drawCircle(h, k, r, originX, originY, user){
  originY-=100;
  let unit= 25;
  if(user){
    fill(0,0,255);
    stroke(0, 0, 255);
  }
  else{
    fill(255, 0,0);
  stroke(255, 0, 0);
  }
  strokeWeight(2);

  push();
  
  translate(originX, originY);
     if(this.showRadius){
    circle(-unit*h, unit*k, 3);
    line(-unit*h, unit*k, -unit*h+unit*sqrt(r), unit*k);
  }
    noFill();

  circle(-unit*h, unit*k, sqrt(r)*unit);

  pop();
}

function drawGrid(centerW, centerH){
  let w=1000;
  let side = w / 2;
  centerH-=100;

  strokeWeight(1);
  stroke(0);
  fill(255);

  rect(centerW, centerH, side, side);
  noFill();

  for (let i = 1; i <= 10; i++) {

    if ((side - i * side / 10) == 0 || (side - i * side / 10) == side) {
      strokeWeight(3);
    } else {
      strokeWeight(1);
    }
    rect(centerW, centerH, side, side - i * side / 10);
    rect(centerW, centerH, side - (i * side / 10), side);

  }

  //axis labels
  strokeWeight(1);
  textSize(15);
  stroke(255, 0, 0);
  textFont(axisFont);
  let digits = ['-10', '-9', '-8', '-7', '-6', '-5', '-4', '-3', '-2', '-1', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];

  for (let i = 0; i <= digits.length; i++) {

    let currentWidth = side / 2 - i * side / 20 + 5;
    let currentHeight = side / 2 - i * side / 20 + 20;
    let y = digits.length - i;
    //x axis 
    if (i != 10) {
      text(digits[i], centerW - currentWidth, centerH + 15);
    }
    //y axis
    if (y != 10) {
      text(digits[y], centerW + 5, centerH - currentHeight);
    } else {
      text(digits[y], centerW + 2, centerH - currentWidth - 8);
    }
  }
}

function windowResized(){
  removeElements();
background(255);
  image(img, 0, 0);
  if(startScreen){
   drawStartScreen();
 }
  else if(level1){
    drawLevelOne();
  }

}










